"""
Django is the python webframework

www.djangoproject.com

user -> browser -> urls -> views -> models -> DB -> templates

MTV -> Model Template View

create a project -

django-admin startproject <projectname>

create a folder in the below structure
    projectname is polling_system

    polling_system - root
        polling_system - python package ( polling_system.urls )
            __init__.py
            settings.py - Configuration for the django project
            urls.py -  table of contents
            asgi.py - ASGI Web Server
            wsgi.py - WSGI Web Server
        manage.py - command-line utility that lets you interact with the django project in several ways.

    running the development server
        -python manage.py runserver <port>/<ip:port> in the root path of the project

    Project - Student Management System
        Timetable
        Exam
        Fees
        Performance

    Project - Polling System
        polls

    python manage.py startapp <appname>

    polls/
        __init__.py
        admin.py
        apps.py
        migrations/
            __init__.py
        models.py
        tests.py
        views.py


    create a route named "hello" and it should "Welcome to the polling system"

    path(pattern,view-method,name,kwargs)

    Project Called Maths
        base-route path("calculator/",include("calculator.urls"))

        Applicaiton called Calculator
            views.py
                add
                mul
                sub
                div
            urls.py
            app-route
                path("addition/",views.add)
                path("mul/",views.mul)
                path("sub/",views.sub)
                path("div/",views.div)

            browser - /calculator/addition -
                      /calculator/add - it will not work

Migrations - capture all your schema changes (model changes)

    django has some default tables

    python manage.py migrate

    python manage.py makemigrations

admin:
    python manage.py createsuperuser

ORM: Object Relational Mapping is a programming technique in which the metadata descriptor is used to
connect the object code to the relational database.

ORM is written in OOP languages such as Java, Python, C#

It convert the data between the systems that are unableto coexist within relational databases and OOP languages

SQLITE DB + PYthon

Give me the ORM for creating the question in two different ways

use Model.save() --> 1

from polls.models import Question
from django.utils import timezone
q = Question(questions = "How are you?",pub_date=timezone.now(),created_at = timezone.now())
q.save()

use Model.objects.create() --> 2

from polls.models import Question
from django.utils import timezone
q = Question.objects.create(questions = "How are you?",pub_date=timezone.now(),created_at = timezone.now())


Choice for the question
-- Choice.objects.create()
-- Choice()
   .save()

Reverse relationship -> question.choice_set
Forward relationship -> choice

Choice.objects.create(choice="I'm fine", votes=0, question=q)
Choice(choice="I'm doing good", votest=0, question=q).save()

Question.objects.get(id=2).choice_set.create(choice="I'm doing well",votes=0)

#for getting the choice for the questions
Question.objects.get(id=2).choice_set.all()

#for getting the question for the choice
Choice.objects.get(id=1).question

Choice.objects.filter(question__id=1).all()

Choice.objects.filter(question__questions="How are you?").all()

"""


"""
Library Project - Web

Django Steps
-> Create Project LMS
-> Create Application 
        Application - Inventory
            Book
            Users
            Author
        
        Book:
            name -> CharField
            author -> ManytoMany ( Author )
            is_available
            topic/category
            place
        Author:
            name
            age - integer -> Char
            address
            phoneno
            licensenumber 
        
        ORM - > Data layer interface
            Author.objects.create(name="sugumar",age=29, address="USA", phoneno="98723")
            

Web
Backend - Db
    Tables
        Rows, Columns
        Columns - schema
        Rows - Data
Model Template View

/createAuthor POST
    name sugumar
    age 30
    address usa
    phoneno 234234
    
    view -> business logic 
        Author.objects.create(name="sugumar",age=29, address="USA", phoneno="98723")
        3
        ORM - DATA layer Creation Read Update Delete

/updateAuthor/3 PUT - here updating author address
    Address IN
        a = Author.objects.get(id=3) 
        a.address = "IN"
        a.save()
 
DML - ORM ( INSERT INTO, UPDATE TABLE, DELETE FROM )
DDL - Migration ( CREATE TABLE, ALTER TABLE, DROP TABLE)
"""


